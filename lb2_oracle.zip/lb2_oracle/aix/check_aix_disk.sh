#!/bin/sh
############################################################################
# Haukur Kristinsson, 2011. Made for AIX 5.3-6.1. IBM FTW!  
# Updated v0.4 by Bernardo S E Vale <bernardo.vale@lb2.com.br>             #
# Written: 25 Jul 2011.                                                    #
# Usage: ./check_filesystems_space [warning] [critical]                    #
# * Attention, warning and critical parameters need to be percentages. *   #
############################################################################
# v0.3 - For loop could terminate to soon as it breaks after proc          #
# v0.4 - Added performance data for /backup and /u01                       #
############################################################################

#Global Variablesi
count=0
output=""

STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKNOWN=3
STATE_DEPENDENT=4
exitstatus=$STATE_UNKNOWN
PERF_DATA="|"
if [ -n "$1" ] && [ -n "$2" ]
then
        warninglimit=$2
        lowlimit=$1

        fses=`df -k | grep / | awk '{ print $7 }'`

        for fs in $fses
        do
                size=`df -k $fs|grep $fs|awk '{ print $4; }'` 
                prc=`echo $size | tr -d "%"`
                if [ $fs == "/proc" ]
                then
                        continue
                fi
                # Add your disk to the IF clause. This will provide performance data to Nagios
                # I don't wanna add all disks since most of then doesn't grow, also if a new disk
                # is added breaks the performance data file (.rrd)
                if [ $fs == "/u01"  ] || [ $fs == "/backup"  ] || [ $fs == "/u02"  ] || [ $fs == "/u03"  ] || [ $fs == "/u04"  ] || [ $fs == "/u05"  ]
                then
                        size_kb=`df -k $fs|grep $fs|awk '{ print $3; }'`
                        size_bytes="$((size_kb * 1024))"
                        #Performance data
                        PERF_DATA="$PERF_DATA free_space_$fs=$size_bytes "
                fi
                if [ $prc -gt $warninglimit ]
                then
                        output=`echo $output "URGENT: Low disk space for $fs ($size) - "`
                        count=`expr $count + 1`
                        if [ $exitstatus -ne 2 ]
                        then
                                exitstatus=$STATE_CRITICAL
                        fi
                elif [ $prc -gt $lowlimit ]
                then
                        output=`echo $output "WARNING: Low disk space for $fs ($size) - "`
                        count=`expr $count + 1`
                        if [ $exitstatus -eq 2 ]
                        then
                                exitstatus=$STATE_CRITICAL
                        else
                                exitstatus=$STATE_WARNING
                        fi
                fi
        done
else
        echo "Arguments not correctly used. Use f.ex. ./check_filesystems_space 90 99, for warning 90 and critical 99."
        exitstatus=$STATE_CRITICAL
fi

#output shall we?
if [ $count -gt 0 ]
then
        echo "$output $PERF_DATA"
else
        if [ -n "$1" ] && [ -n "$2" ]
        then
                echo "OK: Filesystem space inside acceptable levels $PERF_DATA"
                exitstatus=$STATE_OK
        fi
fi

exit $exitstatus