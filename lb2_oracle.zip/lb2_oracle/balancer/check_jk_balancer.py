#!/usr/bin/python
import os
import subprocess
import sys


def call_netstat():
    netstat_wrapper_file = "/opt/lb2_netstat_wrapper.sh"
    session = subprocess.Popen(['/bin/bash', netstat_wrapper_file], stdin=subprocess.PIPE,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = session.communicate()
    if stderr != '':
        print 'UNKNOWN - Impossivel executar o script %s' % netstat_wrapper_file
        exit(3)
    else:
        return stdout


def get_conftab():
    """
    Read conftab file
    :return:
    """
    conftab_path = "/opt/conf.tab"
    x = lambda y: True if os.path.isfile(y) and os.access(y, os.R_OK) else False
    if x(conftab_path):
        with open(conftab_path) as f:
            return ''.join(f.readlines())
    else:
        print "UNKNOWN - Impossivel ler o arquivo %s" %conftab_path
        exit(3)




def get_worker_bind(worker_name, conftab):
    """
    Return the ip and port of a given worker
    if the worker exists on MV conftab
    :param worker_name: str: Name of the worker
    :return:
    """
    for line in conftab.split('\n'):
        if worker_name in line:
            return line.strip()
    return None


def worker_as_dict(conftab_line):
    """
    Returna dict from the confline of the given worker
    :param conftab_line: str: raw conftab line
    :return: dict
    """
    try:
        worker_ip, worker_port, worker_name = str(conftab_line).split(',')
    except ValueError:
        # Treat a conftab_line with a bad pattern
        return None
    worker = {
        'ip': worker_ip,
        'port': worker_port,
        'name': worker_name
    }
    return worker

def get_session_count(netstat_result, worker_dict):
    """
    Get the session count of a worker
    :param netstat_result: str: result from netstat call
    :param worker_dict: dict: worker as a treated dict
    :return: session count
    """
    worker_as_expected = "%s:%s" % (worker_dict['ip'], worker_dict['port'])
    for line in netstat_result.split('\n'):
        if worker_as_expected in line.strip():
            session_count = line.strip().split(worker_dict['ip'])[0]
            try:
                return int(session_count.strip())
            except ValueError:
                return None
    # Couldn't find a connection for given worker
    return 0

def parse_args(argv):
    """
    Parse my arguments
    """
    global worker, warning, critical
    if len(argv) == 5:
        worker = argv[0]
        warning = argv[2]
        critical = argv[4]
    else:
        print "Usage: ./check_jk_balancer.py worker_name -w 10 -c 100"
        exit(3)
    return worker, warning, critical

def main(argv):
    worker, warning, critical = parse_args(argv)
    conftab = get_conftab()
    worker_line = get_worker_bind(worker, conftab)
    if worker_line is None:
        print "UNKWNON - Worker %s inexistente" % worker
        exit(3)
    worker_dict = worker_as_dict(worker_line)
    if worker_dict is None:
        print "UNKWNON - Nao foi possivel extrair os dados do worker %s verifique o conftab" % worker
        exit(3)
    session_count = get_session_count(call_netstat(), worker_dict)
    if session_count is None:
        print "UNKWNON - Nao foi possivel extrair as sessoes do worker %s valide " % worker
        exit(3)
    parse_result(session_count, worker, warning, critical)

def parse_result(session_count, worker, warning, critical):
    exit_status = 0
    if session_count >= int(critical):
        message = 'CRITICAL - Worker %s possui %s conexoes ativas' % (worker, session_count)
        exit_status = 2
    elif session_count >= int(warning):
        message = 'WARNING - Worker %s possui %s conexoes ativas' % (worker, session_count)
        exit_status = 1
    else:
        message = 'OK - Worker %s possui %s conexoes ativas' % (worker, session_count)
    print message + " | SESSIONS=%s" % session_count
    exit(exit_status)

if __name__ == '__main__':
    main(sys.argv[1:])