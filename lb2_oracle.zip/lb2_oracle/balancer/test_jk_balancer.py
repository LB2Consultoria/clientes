import unittest
from check_jk_balancer import get_worker_bind
from check_jk_balancer import worker_as_dict
from check_jk_balancer import get_session_count
from check_jk_balancer import parse_args
class TestJKBalancer(unittest.TestCase):
    """
    Tests related to match_only_if filter for file size
    """

    def setUp(self):
        self.conftab = "172.16.15.16,9250,mvpep8250_sentra \n \
172.16.15.16,9251,mvpep8251_sentra \n \
172.16.15.16,9270,laudosweb8270_sentra \n \
172.16.15.17,9250,mvpep8250_focus \n \
172.16.15.17,9251,mvpep8251_focus \n \
172.16.15.17,9270,laudosweb8270_focus \n \
172.16.15.16,9000,soulmv8000_sentra \n \
172.16.15.16,9001,soulmv8001_sentra \n \
172.16.15.17,9000,soulmv8000_focus \n \
172.16.15.17,9001,soulmv8001_focus \n \
172.16.15.16,9250,mvpep8250_sentra \n \
172.16.15.16,9251,mvpep8251_sentra \n \
172.16.15.16,9270,laudosweb8270_sentra \n \
172.16.15.17,9250,mvpep8250_focus \n \
172.16.15.17,9251,mvpep8251_focus \n \
172.16.15.21,9250,mvpep8250_SPIN \n \
172.16.15.21,9251,mvpep8251_SPIN \n \
172.16.15.21,9270,laudosweb8270_SPIN \n \
172.16.15.20,9250,mvpep8250_PRIUS \n \
172.16.15.20,9251,mvpep8251_PRIUS \n \
172.16.15.20,9270,laudosweb8270_PRIUS \n \
172.16.15.17,9270,laudosweb8270_focus \n \
172.16.15.16,9000,soulmv8000_sentra \n \
172.16.15.16,9001,soulmv8001_sentra \n \
172.16.15.17,9000,soulmv8000_focus \n \
172.16.15.17,9001,soulmv8001_focus \n \
172.16.15.21,9000,soulmv8000_SPIN \n \
172.16.15.21,9001,soulmv8001_SPIN \n \
172.16.15.20,9000,soulmv8000_PRIUS \n \
172.16.15.20,9001,soulmv8001_PRIUS"
        self.netstat_result = "     25 172.16.15.17:9001 \n \
     22 172.16.15.17:9000 \n \
     20 172.16.15.16:9001 \n \
     16 172.16.15.17:9251 \n \
     15 172.16.15.16:9251 \n \
     11 172.16.15.16:9250 \n \
     10 172.16.15.16:9000 \n \
      7 172.16.15.17:9250 \n \
      1 172.16.70.70:60805 \n \
      1 172.16.0.6:3579 "
        pass

    def tearDown(self):
        pass

    def test_get_worker_bind(self):

        worker_result = get_worker_bind('soulmv8000_sentra', self.conftab)
        self.assertEquals((worker_result), '172.16.15.16,9000,soulmv8000_sentra')
        worker_result = get_worker_bind('laudosweb8270_PRIUS', self.conftab)
        self.assertEquals(worker_result, '172.16.15.20,9270,laudosweb8270_PRIUS')
        self.assertEquals(get_worker_bind('should find nothing', self.conftab), None)

    def test_get_worker_as_dict(self):
        confline = '172.16.15.20,9270,laudosweb8270_PRIUS'
        result = worker_as_dict(confline)
        self.assertEquals(dict, type(result))
        expected_dict = {
            'ip': '172.16.15.20',
            'port': '9270',
            'name': 'laudosweb8270_PRIUS'
        }
        self.assertEquals(expected_dict, result)
        another_dict = {
            'ip': '172.16.15.17',
            'port': '9250',
            'name': 'mvpep8250_focus'
        }
        result2 = worker_as_dict('172.16.15.17,9250,mvpep8250_focus')
        self.assertEquals(result2, another_dict)

        result3 = worker_as_dict('confline_bad_pattern')
        self.assertEquals(result3, None)

    def test_session_count(self):
        worker_dict = {
            'ip': '172.16.15.17',
            'port': '9250',
            'name': 'mvpep8250_focus'
        }
        session_count = get_session_count(self.netstat_result, worker_dict)
        self.assertEquals(session_count, 7)
        another_worker = {
            'ip': '172.16.15.17',
            'port': '9000',
            'name': 'soulmv8000_focus'
        }
        session_count = get_session_count(self.netstat_result, another_worker)
        self.assertEquals(session_count, 22)
        worker_without_connections = {
            'ip': '172.16.15.17',
            'port': '9999',
            'name': 'soulmv8000_focus'
        }
        session_count = get_session_count(self.netstat_result, worker_without_connections)
        self.assertEquals(session_count, 0)

    def test_parse_args(self):
        argv = ['capa', '-w', 100, '-c', 150]
        expected = ('capa', 100, 150)
        result = parse_args(argv)
        self.assertEquals(expected, result)