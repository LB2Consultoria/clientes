#!/usr/bin/python
from __future__ import with_statement
import time
import re

find_str = "CONFIG ERRORS"
fname = "/Users/bernardovale/bpi.log"
epoch_time = int(time.time())

with open(fname, "r") as f:
    f.seek (0, 2)
    fsize = f.tell()
    f.seek (max (fsize-1024, 0), 0)
    lines = f.readlines()

lines = lines[-5:]

for line in lines:
    if find_str in line:
        extract_date = re.findall('\d+', line)[0]
        time_ago = epoch_time - int(extract_date)
        if time_ago > 240:
            pass
        else:
            print 'CRITICAL - Erro no configuracao do BPI. Verifique se algo foi excluido ou alterado'
            exit(2)
print "BPI OK"
exit(0)