#!/usr/bin/python
# -*- coding: utf-8 -*-

from utils.monitoramento_utils import Utils
from utils.database_utils import Db


__author__ = 'Bruno Teruya'
__copyright__ = 'LB2 Consultoria'

def main(sid, user, password, warning, critical, tempo_lock):
    result = ''
    query = "set lines 200  \n \
            col blocked_sid format 999999  \n \
            col time_blocked format 999999999999 \n \
            set head off \n \
            set feedback off \n \
            WITH my_ddf AS ( \n \
            select blocked.sid blocked_sid, \n \
                   blocked.ctime time_blocked \n \
              from gv$lock blocked,  \n \
                   (select * \n \
                     from gv$lock \n \
                    where block != 0 \n \
                      and type = 'TX' ) blocker \n \
             where blocked.type = 'TX' \n \
               and blocked.block = 0 \n \
               and blocked.id1 = blocker.id1) select * from my_ddf;"
   
    m = Monitoring(sid, user, password, warning, critical, tempo_lock)

    m.result = Db.multiple_query(user, password, sid, query)

    m.check_parameters()
    m.build_locks()
    m.check_if_ok()
    m.build_perfdata()
    m.finish_with_output()


class Monitoring:
    exit = 0
    perf_data = '| '
    lock_count = 0
    long_lock_count = 0
    locks = []

    def check_parameters(self):
        if (self.tempo_lock <= 0):
            print 'UNKNOWN Erro em alguma consulta ou na leitura dos parametros.'
            exit(3)
        if (self.warning <= 0):
            print 'UNKNOWN Erro em alguma consulta ou na leitura dos parametros.'
            exit(3)
        if (self.critical <= 0):
            print 'UNKNOWN Erro em alguma consulta ou na leitura dos parametros.'
            exit(3)

    def __init__(self, sid, user, password, warning, critical, tempo_lock):
        self.sid = sid
        self.user = user
        self.password = password
        self.warning = warning
        self.critical = critical
        self.tempo_lock = tempo_lock

    def check_lock(self, lock):
        """
        Verifica se o lock é um lock válido pelo tempo 
        de bloqueado comparado com tempo_lock e
        verifica se a quantidade de lock se esta com 
        tempo de lock acima do parametro warning e critical
        :param lock:
        :return:
        """
        if int(lock.time_blocked) >= int(self.tempo_lock):
            self.long_lock_count += 1 
        self.lock_count += 1
            
    def check_if_ok(self):
        """
        Verifica se os locks estao ok
        :return:
        """
        for lock in self.locks:
            self.check_lock(lock)
        if int(self.long_lock_count >= self.warning):
            self.exit = 1
        if int(self.long_lock_count >= self.critical):
            self.exit = 2

    def build_locks(self):
        """
        Constroi uma lista de locks a partir
        da lista construida com o resultado
        da query
        """
        for lista in self.result:
            if (not lista == []):
                sid = lista[0]
                time_blocked = lista[1]
                self.locks.append(Lock(sid, time_blocked))


    def finish_with_output(self):
        """
        Formatação do resultado final do script
        :return:
        """
        if self.exit == 0:
            print 'OK %s (Quantidade de locks) sessoes bloqueadas a mais de %d segundos.%s ' % (self.lock_count, int(self.tempo_lock), self.perf_data)
        elif self.exit == 1:
            print 'WARNING %s (Quantidade de locks) sessoes bloqueadas a mais de %d segundos.%s' % (self.lock_count, int(self.tempo_lock), self.perf_data)
        elif self.exit == 2:
            print 'CRITICAL %s (Quantidade de locks) sessoes bloqueadas a mais de %d segundos.%s' % (self.lock_count, int(self.tempo_lock), self.perf_data)
            
        exit(self.exit)

    def build_perfdata(self):
        """
        Constroi o valor do perdata
        :return:
        """
        self.perf_data += "{0:s}={1:s} {2:s}={3:s}".format('LOCKS', str(self.lock_count),
                                                           'LONG_LOCKS', str(self.long_lock_count))

class Lock:
    def __init__(self, sid, time_blocked):
        self.sid = sid
        self.time_blocked = time_blocked
