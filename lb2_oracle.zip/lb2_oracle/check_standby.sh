#!/bin/sh
#########################################################################################
#       Autor: Tiago Furlaneto
#       Data: 21/05/2014
#       Descrição: Script do nagios com intuito de verificar a sincronizacao do PHYSICAL STANDBY MANUAL
#
#                               Modificações
#########################################################################################
#               DATA            |       DESCRIÇÃO
#########################################################################################
#               21/05/2014      | Início do script
#               03/07/2014      | Adicao de dado (MINUTES_DIFF) para plotagem
#
#               Propriedade da LB2 Consultoria e Tecnologia S/S
#########################################################################################
# Help
############################################################################################
#
# TO PRINT THE HELP, CALL THE SCRIPT WITHOUT ANY OR LESS THAN 4 ARGUMENTS:
#./check_standby_sync.sh
#
printHelp(){
echo "USAGE: (needs ORACLE_HOME to be set)"
echo './check_standby_sync.sh $ARG1 $ARG2 $ARG3 $ARG4'
echo
echo "ARGUMENTS:"
echo
echo '$ARG1 = PRODUCTION DATABASE TNS'
echo '$ARG2 = STANDBY TNS'
echo '$ARG3 = WARNING THRESHOLD (maximum time allowed for the sync to be "out-of-date", considered a WARNING)'
echo '$ARG4 = CRITICAL THRESHOLD (maximum time allowed for the sync to be "out-of-date", considered a CRITICAL state)'
}
#
############################################################################################
#                               Declaração de Variáveis - Options
#########################################################################################
# Ambiente

export PATH=$ORACLE_HOME/bin:$HOME/bin:$PATH:/bin:/usr/bin:/usr/sbin:/sbin

# ORACLE
export PROD_PASS="passw0rd"
export STANDBY_PASS="passw0rd"
export TNS_PRODUCAO=$1
export TNS_STANDBY=$2
export ORACLE_HOSTNAME=ORAPRD
export ORACLE_BASE=/u01/app/oracle
export ORACLE_HOME=$ORACLE_BASE/product/12.2.0/db_1
export ORACLE_SID=sag
export PATH=$ORACLE_HOME/bin:$PATH
export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib
export CLASSPATH=$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib

export HISTFILESIZE=1500
export HISTTIMEFORMAT="%d/%m/%y %T "

# Estados do script
export STATE_OK=0
export STATE_WARNING=1
export STATE_CRITICAL=2
export STATE_UNKNOWN=3

# Thresholds
export WARNING_THRESHOLD=$3
export CRITICAL_THRESHOLD=$4

##########################################################################################
# Diversos
##########################################################################################
#                               Funções do Programa
##########################################################################################
#Busca no banco o local onde esta sendo gravado o alert Log.
checkSync(){

# Conecta no producao e traz informacoes
export PROD_LAST_LOG=`$ORACLE_HOME/bin/sqlplus -S -L sys/$PROD_PASS@$TNS_PRODUCAO as sysdba << EOF
        set echo off heading off feedback off
        alter session set nls_date_format='YYYY-MM-DD HH24:MI';
        select SEQUENCE#||' '||FIRST_TIME from v\\$archived_log where FIRST_TIME=(select max(first_time) from v\\$archived_log);
        exit
EOF`

export PROD_SEQUENCE=`echo $PROD_LAST_LOG | awk '{ print $1 }'`
export PROD_DATE=`echo $PROD_LAST_LOG | awk '{ print $2 }'`
export PROD_TIME=`echo $PROD_LAST_LOG | awk '{ print $3 }'`
export PROD_DATETIME=$PROD_DATE' '$PROD_TIME

# Conecta no standby e traz informacoes
export STANDBY_LAST_LOG=`$ORACLE_HOME/bin/sqlplus -S -L sys/$STANDBY_PASS@$TNS_STANDBY as sysdba << EOF
        set echo off heading off feedback off
        alter session set nls_date_format='YYYY-MM-DD HH24:MI';
        select SEQUENCE#||' '||FIRST_TIME from v\\$log_history where FIRST_TIME=(select max(first_time) from v\\$log_history);
        exit
EOF`

export STANDBY_SEQUENCE=`echo $STANDBY_LAST_LOG | awk '{ print $1 }'`
export STANDBY_DATE=`echo $STANDBY_LAST_LOG | awk '{ print $2 }'`
export STANDBY_TIME=`echo $STANDBY_LAST_LOG | awk '{ print $3 }'`
export STANDBY_DATETIME=$STANDBY_DATE' '$STANDBY_TIME

# Realiza calculos para verificar a diferenca
SECONDS_PROD=`date --date="$PROD_DATETIME" +'%s'`
SECONDS_STANDBY=`date --date="$STANDBY_DATETIME" +'%s'`
SECONDS_DIFF=`expr $SECONDS_PROD - $SECONDS_STANDBY`
MINUTES_DIFF=`expr $SECONDS_DIFF / 60`

}
#Da o veredito para o cabron, OK,CRITICAL,WARNING
checkResult(){
if [ $MINUTES_DIFF -le $WARNING_THRESHOLD ]; then
        echo "OK - PROD-SEQ: "$PROD_SEQUENCE" / TIME: "$PROD_DATETIME" /// STANDBY_SEQ: "$STANDBY_SEQUENCE" / TIME: "$STANDBY_DATETIME".|MINUTES_DIFF="$MINUTES_DIFF
        exit $STATE_OK
elif [ $MINUTES_DIFF -gt $CRITICAL_THRESHOLD ]; then
        echo "DIFFERENCE TOO HIGH!! REVIEW THE SYNCHRONIZATION!! ==> PROD-SEQ: "$PROD_SEQUENCE" / TIME: "$PROD_DATETIME" /// STANDBY_SEQ: "$STANDBY_SEQUENCE" / TIME: "$STANDBY_DATETIME".|MINUTES_DIFF="$MINUTES_DIFF
        exit $STATE_CRITICAL
elif [ $MINUTES_DIFF -gt $WARNING_THRESHOLD ]; then
        echo "DIFFERENCE ABOVE THE ACCEPTABLE ("$WARNING_THRESHOLD" minutes) ==> PROD-SEQ: "$PROD_SEQUENCE" / TIME: "$PROD_DATETIME" /// STANDBY_SEQ: "$STANDBY_SEQUENCE" / TIME: "$STANDBY_DATETIME".|MINUTES_DIFF="$MINUTES_DIFF
        exit $STATE_WARNING
else
        echo "UNKNOWN ERROR."
        exit $STATE_UNKNOWN
fi
}
##########################################################################################
#                               Chamada Principal
##########################################################################################
if [ ! -x "$ORACLE_HOME/bin/sqlplus" ]; then
    echo "Error: $ORACLE_HOME/bin/sqlplus not found or not executable."
    exit $STATE_UNKNOWN
elif [ "$1" = "" ] || [ "$2" = "" ] || [ "$3" = "" ] || [ "$4" = "" ]; then
    printHelp
    exit $STANTE_UNKOWN
else
        checkSync
        checkResult
fi
##########################################################################################
#                                 Fim do Script
##########################################################################################

