from datetime import timedelta
from utils.database_utils import Db
from utils.date_utils import DateUtils
from utils.monitoramento_utils import Utils

__author__ = 'bernardovale'


class Statistics:
    def __init__(self, date=None, stale_count=None, jobs=None):
        self.date = date
        self.stale_count = stale_count
        self.jobs = jobs


class Monitoring:
    def __init__(self, sid, user, password, jobs, force, alert_time, warning_stale, critical_stale, check_oracle):
        self.sid = sid
        self.user = user
        self.password = password
        self.jobs = jobs
        self.force = force
        self.alert_time = alert_time
        self.warning_stale = warning_stale
        self.critical_stale = critical_stale
        self.check_oracle = check_oracle
        self._stale_count = 0
        self._temp_file = "data/check_statistics_%s.json" % sid
        self._jobs_status = []
        self._gather_result = Statistics()
        self._exit_status = 0
        self._jobs_problem_count = 0

    def write_last_result(self):
        """
        Write last gather result
        :return:
        """
        last_result = {
            'date' : self._gather_result.date,
            'stale_count' : self._gather_result.stale_count,
            'jobs' : self._gather_result.jobs
        }
        Utils.write_gather_json(self._temp_file, last_result)

    def read_last_result(self):
        """
        Read from JSON the last gather result
        :return: Statistics
        """
        last_result = Utils.read_json(Utils.fullpath(self._temp_file))
        return Statistics(
            last_result['date'],
            last_result['stale_count'],
            last_result['jobs']
        )

    def still_fresh(self, gather_date):
        """
        Check if gather date it' older
        then four hours.
        :return: bool
        """
        delta = DateUtils.hours_delta(gather_date)
        return True if delta < timedelta(hours=int(self.alert_time)) else False

    def should_work(self):
        """
        Check if should do it's job or just
        read the last result from json
        :return: bool
        """
        #If it's a force check you should work!
        if not self.force:
            # First need check if json exists
            if Utils.file_exists_not_empty(Utils.fullpath(self._temp_file)):
                # step 2 - Check if last result didn't timeout
                self._gather_result = self.read_last_result()
                if self.still_fresh(self._gather_result.date):
                    return False
            # should work!
        return True

    def find_stale(self):
        """
        Search for stale objects within the database.
        :return:
        """
        query = "set feedback off \n \
                set head off \n \
                select count(*) as c \n \
	            FROM all_tab_statistics \n \
	            WHERE (last_analyzed IS NULL OR stale_stats = 'YES') and stattype_locked IS NULL \n \
	            and owner NOT IN ('ANONYMOUS', 'CTXSYS', 'DBSNMP', 'EXFSYS','LBACSYS','MDSYS', \n \
                'MGMT_VIEW','OLAPSYS','OWBSYS','ORDPLUGINS','ORDSYS','OUTLN','SI_INFORMTN_SCHEMA', \n \
                'SYS', 'SYSMAN', 'ORDDATA', 'SYSTEM','TSMSYS','WK_TEST','WKSYS','WKPROXY','WMSYS','XDB' ) \n \
	            AND owner NOT LIKE 'FLOW%' \n \
	            and owner not like 'APEX%' \n \
	            AND table_name not like 'BIN$%' \n \
	            and table_name not like 'TMP_%' \n \
	            and table_name not like 'MLOG$_%' \n \
	            and table_name not like 'RUPD$_%';"
        self._gather_result.stale_count = Db.single_int_query(self.user, self.password, self.sid, query)

    def populate_job(self, job_name, status):
        """
        Do a simple validation of the job status
        and populate it on job_list
        :param job_name: str: Job Name
        :param status: str: Status of the last execution
        :return: None
        """
        job = {
            'name': job_name,
            'status': status
        }
        self._gather_result.jobs.append(job)

    def check_automatic_job(self):
        """
        Check the last execution status
        of Oracle Automatic Optimizer Statistics
        Gathering
        :return:
        """
        query = "set feedback off \n \
                set head off \n \
                select \n \
                    case when s.JOB_START_TIME < sysdate-3 then \n \
                        'TOO_OLD' \n \
                    else \n \
                        s.job_status \n \
                    end \n \
                    last_job from (select job_status,JOB_START_TIME \n \
	                                from DBA_AUTOTASK_JOB_HISTORY \n \
                                    where client_name = 'auto optimizer stats collection' \n \
	                                order by JOB_START_TIME desc) s \n \
                where rownum =1;"
        job_status = Db.single_string_query(self.user, self.password, self.sid, query)
        self.populate_job('ORACLE_AUTOMATIC_JOB', job_status)

    def init_gather(self):
        """
        Start the Statistics obj
        :return: None
        """
        today = DateUtils.get_date_hour()
        self._gather_result.date = today
        self._gather_result.stale_count = self._stale_count
        self._gather_result.jobs = self._jobs_status

    def check_jobs(self):
        """
        Check the last execution status
        of each job from the given list
        :return:
        """

        for job in self.jobs:
            query = "set head off \n \
                set feedback off \n \
                select s.status \n \
                from \n \
                (select status \n \
                from DBA_SCHEDULER_JOB_RUN_DETAILS \n \
                where job_name = '%s' \n \
                order by LOG_DATE desc) s \n \
                where rownum =1 \n \
                UNION ALL \n \
                select 'EMPTY' status \n \
                from dual \n \
                where not exists (select status \n \
                    from DBA_SCHEDULER_JOB_RUN_DETAILS \n \
                    where job_name = '%s');" % (job, job)
            job_status = Db.single_string_query(self.user, self.password, self.sid, query)
            self.populate_job(job, job_status)

    def parse_result(self, msg):
        """
        Exit with the correct status
        build performance data and
        write the exit message
        :param msg: Exit Message
        :return: None
        """
        perf_data = " | STALE_COUNT=%s JOBS_PROBLEM=%s" % (self._gather_result.stale_count, self._jobs_problem_count)
        result = msg + perf_data
        print result
        exit(self._exit_status)

    def find_issues(self):
        """
        Parse result and check if
        there's any problem within the
        database
        :return:
        """
        job_names = []
        jobs_with_problem = "ATENCAO:"
        exit_msg = ""
        stale_msg = "%s objetos stale encontrados." % self._gather_result.stale_count
        # Check jobs status
        for job in self._gather_result.jobs:
            if job['status'] != 'SUCCEEDED':
                self._exit_status = 1
                self._jobs_problem_count += 1
                job_error = " JOB %s com status %s" % (job['name'], job['status'])
                jobs_with_problem += job_error
            else:
                job_names.append(job['name'])
        if self._gather_result.stale_count >= self.critical_stale:
            stale_msg = "Excesso de objetos stale, %s encontrados." % self._gather_result.stale_count
            self._exit_status = 2
        elif self._gather_result.stale_count >= self.warning_stale:
            stale_msg = "Excesso de objetos stale, %s encontrados." % self._gather_result.stale_count
            self._exit_status = 1
        # Build exit message
        #Build jobs ok!
        jobs_str = ", ".join(job_names)
        jobs_ok = "Os Jobs %s foram executados com sucesso!" % (jobs_str)
        if self._exit_status == 0:
            exit_msg = stale_msg + jobs_ok
        else:
            #Should print jobs errors?
            if self._jobs_problem_count > 0:
                exit_msg = stale_msg + jobs_with_problem
            else:
                exit_msg = stale_msg + jobs_ok
        self.parse_result(exit_msg)




def main(sid, user, password, jobs, force, alert_time, warning_stale, critical_stale, check_oracle):
    m = Monitoring(sid, user, password, jobs, force, alert_time, warning_stale, critical_stale, check_oracle)
    if m.should_work():
        m.init_gather()
        if m.check_oracle:
            m.check_automatic_job()
        if m.jobs is not []:
            m.check_jobs()
        m.find_stale()
    m.write_last_result()
    m.find_issues()
