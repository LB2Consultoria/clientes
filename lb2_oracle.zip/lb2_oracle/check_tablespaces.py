# coding=utf-8
from datetime import timedelta
from utils.date_utils import DateUtils
from utils.monitoramento_utils import Utils

__author__ = 'bernardovale'

query = " set head off \n \
        set feedback off \n \
        WITH my_ddf AS \n \
    ( \n \
        SELECT file_id, tablespace_name, file_name, \n \
               DECODE (autoextensible, \n \
                       'YES', GREATEST (BYTES, maxbytes), \n \
                       BYTES \n \
                      ) mysize, \n \
              DECODE (autoextensible, \n \
                      'YES', CASE \n \
                         WHEN (maxbytes > BYTES) \n \
                            THEN (maxbytes - BYTES) \n \
                         ELSE 0 \n \
                      END, \n \
                      0 \n \
                     ) growth \n \
         FROM dba_data_files) \n \
SELECT   my_ddf.tablespace_name, \n \
         100 - ROUND (  (SUM (NVL (freebytes, 0)) + SUM (growth)) \n \
                 / SUM (my_ddf.mysize) \n \
                 * 100 \n \
               ) PERCENT_UTILIZADO, \n \
              '____' \n \
    FROM my_ddf, (SELECT   file_id, SUM (BYTES) freebytes \n \
                      FROM dba_free_space \n \
                  GROUP BY file_id) dfs \n \
   WHERE my_ddf.file_id = dfs.file_id(+) \n \
         AND my_ddf.tablespace_name NOT LIKE '%UNDOTB%' \n \
GROUP BY my_ddf.tablespace_name;"


def main(sid, user, password, warning, critical, force, exec_time, autoextend=None):
    m = Monitoring(sid, user, password, warning, critical, force, exec_time, autoextend)
    if m.should_work():
        if user.lower() == 'sys':
            result = Utils.run_sqlplus(password, user, sid, query, True, True)
        else:
            result = Utils.run_sqlplus(password, user, sid, query, True, False)
        if 'ORA-' in result:
            print 'UNKNOWN - Erro desconhecido ao executar a query:' + result
            exit(3)
        m.parse_result(result)
        m.build_v2_tablespace()
        m.check_if_ok()
        m.build_perfdata()
        m.populate_output()
        m.write_gather()
    m.exit_with_output()



class Monitoring:
    exit = 0
    perf_data = '| '
    critical_tablespaces = ''
    warning_tablespaces = ''
    warning_count = 0
    critical_count = 0
    tablespaces = []

    def __init__(self, sid, user, password, warning, critical, force, exec_time, autoextend=None):
        self.sid = sid
        self.user = user
        self.password = password
        self.warning = warning
        self.critical = critical
        self.autoextend = autoextend
        self.force = force
        self.exec_time = exec_time
        self._temp_file = "data/check_tablespaces_%s.json" % self.sid
        self._last_result = {}
        self._gather_result = Gather()

    def should_work(self):
        """
        Define se deve ou nao realizar seu trabalho
        :return: bool
        """
         #If it's a force check you should work!
        if not self.force:
            # First need check if json exists
            if Utils.file_exists_not_empty(Utils.fullpath(self._temp_file)):
                # step 2 - Check if last result didn't timeout
                self._gather_result = self.read_last_result()
                if self.still_fresh(self._gather_result.date):
                    return False
        # should work!
        return True

    def check_tablespace(self, tablespace):
        """
        Verifica a tablespace e possiveis erros de size
        :param tablespace:
        :return:
        """
        if int(tablespace.pct_used) >= int(self.warning):
            self.exit = 1
            if int(tablespace.pct_used) >= int(self.critical):
                self.exit = 2
            self.append_tablespace_problem(tablespace.name, tablespace.pct_used)

    def check_if_ok(self):
        """
        Verifica se as tablespaces estao ok
        baseado nos thresholds
        :return:
        """
        for ts in self.tablespaces:
            self.check_tablespace(ts)

    # def parse_result(self, r):
    #     """
    #     Realiza os tratamentos no resultado da query
    #     :type self: object
    #     :param r: Retorno da query
    #     :return: Lista com resultado formatado
    #     """
    #     self.result = r.strip()
    #     self.result = self.result.replace("|", " ")
    #     self.result = self.result.replace("     ", " ")
    #     self.result = self.result.replace("    ", " ")
    #     self.result = self.result.replace("   ", " ")
    #     self.result = self.result.replace("  ", " ")
    #     self.result = self.result.replace('____', ' YES ').split(' ')

    def parse_result(self, r):
        """
        Realiza os tratamentos no resultado da query
        :type self: object
        :param r: Retorno da query
        :return: Lista com resultado formatado
        """
        self.result = r.strip()
        self.result = self.result.replace("|", " ")
        self.result = self.result.split("____")
        self.result = [s.split() for s in self.result]


    def build_v2_tablespace(self):
        """
        Constroi uma lista de tablespaces a partir
        da lista construida com o resultado
        :return:
        """
        for ts in self.result:
            if ts:
                self.tablespaces.append(Tablespace(ts))

    def build_tablespaces(self):
        """
        Constroi uma lista de tablespaces a partir
        da lista construida com o resultado
        da query
        """
        ts_tuples = zip(*[iter(self.result)] * 3)
        for i in ts_tuples:
            self.tablespaces.append(Tablespace(i))

    def append_tablespace_problem(self, name, pct_used):
        """
        Adiciona o nome e os valores das tablespaces
        para mencionar no output final
        :param name: Nome da tablespace
        :param pct_used: porcentagem de utilização
        :return:
        """
        if self.exit == 1:
            self.warning_count += 1
            self.warning_tablespaces += "%s %s%% " % (name, pct_used)
        else:
            self.critical_count += 1
            self.critical_tablespaces += "%s %s%% " % (name, pct_used)

    def populate_output(self):
        """
        Formatação do resultado final do script
        :return:
        """

        if self.exit == 0:
            self.output = 'TABLESPACES OK %s' % self.perf_data
        elif self.exit == 1:
            self.output = 'TABLESPACES WARNING - %s %s' % (self.warning_tablespaces, self.perf_data)
        elif self.exit == 2:
            self.output = 'TABLESPACES CRITICAL - %s %s %s' % (self.warning_tablespaces,
                                                       self.critical_tablespaces, self.perf_data)

    def build_perfdata(self):
        """
        Constroi o valor do perdata
        :return:
        """
        self.perf_data += "{0:s}={1:s} {2:s}={3:s}".format('WARNING', str(self.warning_count),
                                                           'CRITICAL', str(self.critical_count))

    def read_last_result(self):
        """
        Realiza a leitura do ultimo resultado
        :return:
        """
        last_result = Utils.read_json(Utils.fullpath(self._temp_file))
        return Gather(
            last_result['date'],
            last_result['exit'],
            last_result['output']
        )

    def still_fresh(self, gather_date):
        """
        Check if gather date it' older
        then four hours.
        :return: bool
        """
        delta = DateUtils.hours_delta(gather_date)
        return True if delta < timedelta(hours=int(self.exec_time)) else False

    def write_gather(self):
        """
        Registra a coleta
        :return:
        """
        _last_result = {
            'date' : DateUtils.get_date_hour(),
            'exit' : self.exit,
            'output' : self.output
        }
        self._gather_result = Gather(
            date = _last_result['date'],
            exit = _last_result['exit'],
            output = _last_result['output']
        )
        Utils.write_gather_json(self._temp_file, _last_result)

    def exit_with_output(self):
        """
        Exit and print output from last_exec
        :return:
        """
        print self._gather_result.output
        exit(self._gather_result.exit)

class Gather:
    def __init__(self, date=None, exit=None, output=None):
        self.date = date
        self.exit = exit
        self.output = output

# class Tablespace:
#     def __init__(self, ts):
#         self.name, self.pct_used, _ = ts

class Tablespace:
     def __init__(self, ts):
         self.name = ts[0]
         self.pct_used = ts[1]
