#!/usr/bin/python
# -*- coding: utf-8 -*-

from utils.monitoramento_utils import Utils
from utils.database_utils import Db


__author__ = 'Bruno Teruya'
__copyright__ = 'LB2 Consultoria'

def main(sid, user, password, warning):

    query = "set lines 200  \n \
             column classe format a20 \n \
             column time_secs format 999999999999999 \n \
             set head off \n \
             set feedback off \n \
             WITH my_ddf AS \n \
              ( \n \
             SELECT classe, SUM(time_secs) time_secs \n \
               FROM (  \n \
                 SELECT 0 AS time_secs, REPLACE(wait_class,' ','_') AS classe  \n \
                   FROM v$event_name w  \n \
                  WHERE wait_class != 'Idle' \n \
                 UNION  \n \
                 SELECT SUM(NVL(S.WAIT_TIME_MICRO,0)/1000) AS time_secs, REPLACE(w.wait_class,' ','_') AS classe  \n \
                   FROM v$session_wait s RIGHT OUTER JOIN v$system_wait_class w  \n \
                        ON (w.wait_class = s.wait_class)  \n \
                  WHERE s.state = 'WAITING'  \n \
                   AND s.wait_class != 'Idle'  \n \
                   GROUP BY w.wait_class)  \n \
                   GROUP BY classe  \n \
                   ORDER BY classe) select * from my_ddf;"

    m = Monitoring(sid, user, password, warning)
    # result = Db.single_int_query(user, password, sid, query)

    m.result = lista = Db.multiple_query(user, password, sid, query)

    m.build_waits()
    m.check_if_ok()
    m.check_biggest_wait()
    m.build_perfdata()
    m.finish_with_output()


class Monitoring:
    exit = 0
    perf_data = '| '
    waits = []
    biggest_wait = None

    def __init__(self, sid, user, password, warning):
        self.sid = sid
        self.user = user
        self.password = password
        self.warning = warning
        if sid is None or user is None or password is None or warning is None:
            print 'UNKNOWN - Erro em alguma consulta ou na leitura dos parametros.'
            exit(3)
        if sid == '' or user == '' or password == '' or warning == '':
            print 'UNKNOWN - Erro em alguma consulta ou na leitura dos parametros.'
            exit(3)

    def check_wait(self, wait):
        """ 
        Verifica a wait se esta com wait acima do parametro warning
        :param wait:
        :return:
        """
        try:
            if float(wait.time_waited) >= float(self.warning):
                self.exit = 1
        except:
            print 'UNKNOWN - Erro em alguma consulta ou na leitura dos parametros.'
            exit(3)

    def check_if_ok(self):
        """
        Verifica se as waits estao ok
        baseado nos thresholds
        :return:
        """
        for wait in self.waits:
            self.check_wait(wait)

    def build_waits(self):
        """
        Constroi uma lista de waits a partir
        da lista construida com o resultado
        da query
        """
        try:
            for lista in self.result:
                if not lista == []:
                    name = lista[0]
                    time_waited = lista[1]
                    self.waits.append(Wait(name, time_waited))

        except:
            print 'UNKNOWN - Erro em alguma consulta ou na leitura dos parametros.'
            exit(3)

    def check_biggest_wait(self):
        try :
            for wait in self.waits:
                if self.biggest_wait is None:
                    self.biggest_wait = wait
                else:
                  if int(self.biggest_wait.time_waited) < int(wait.time_waited):
                      self.biggest_wait = wait
        except:
            print 'UNKNOWN - Erro em alguma consulta ou na leitura dos parametros.'
            exit(3)

    def finish_with_output(self):
        """
        Formatação do resultado final do script
        :return:
        """
        mensagem = ''
        if self.exit == 0:
            mensagem = 'OK'
        elif self.exit == 1:
            mensagem = 'WARNING'
        print '%s - Classe %s somando %s segundos de espera no banco %s' % (mensagem, self.biggest_wait.name,self.biggest_wait.time_waited,self.perf_data)
        exit(self.exit)

    def build_perfdata(self):
        """
        Constroi o valor do perdata
        :return:
        """
        for wait in self.waits:
            self.perf_data += "%s=%s " % (wait.name, wait.time_waited)

class Wait:
    def __init__(self, name, time_waited):
        self.name = name
        self.time_waited = time_waited
