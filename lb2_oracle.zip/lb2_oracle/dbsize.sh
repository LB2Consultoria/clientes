#!/usr/bin/bash

# Estados do script
export STATE_OK=0
export STATE_WARNING=1
export STATE_CRITICAL=2
export STATE_UNKNOWN=3

# Thresholds
export WARNING_THRESHOLD=$1
export CRITICAL_THRESHOLD=$2
export ORASID=$3

export DBSIZE_RESULT=`$ORACLE_HOME/bin/sqlplus -s lb2bkp/alsk1029QWE#@$ORASID << EOF
set echo off head off feedback off
column TOTAL_UTILIZADO_SIZE       format 99999999
SELECT  LTRIM(TRUNC(SUM((A.BYTES-B.BYTES))/1024/1024)) TOTAL_UTILIZADO_SIZE
FROM
(   SELECT  x.TABLESPACE_NAME, SUM(x.BYTES) BYTES
FROM    DBA_DATA_FILES x,DBA_TABLESPACES y
WHERE y.CONTENTS <>'UNDO'
AND x.TABLESPACE_NAME=y.TABLESPACE_NAME
GROUP BY x.TABLESPACE_NAME) A,
(   SELECT  TABLESPACE_NAME, SUM(BYTES) BYTES
FROM    DBA_FREE_SPACE
GROUP BY TABLESPACE_NAME) B
WHERE  A.TABLESPACE_NAME=B.TABLESPACE_NAME;
exit
EOF`

export DBSIZE=`echo $DBSIZE_RESULT | awk '{ print$1 }'`
#echo "DBSIZE = $DBSIZE;;;;"

checkResult(){
if [ "$DBSIZE" -lt "$WARNING_THRESHOLD" ]; then
        echo "OK DBSIZE=$DBSIZE MB | DBSIZE=$DBSIZE"MB";;;;"
        exit $STATE_OK
elif [ "$DBSIZE" -gt  "$CRITICAL_THRESHOLD" ]; then
        echo "Critical DBSIZE=$DBSIZE MB | DBSIZE=$DBSIZE"MB";;;;"
        exit $STATE_CRITICAL
elif [ "$DBSIZE" -gt "$WARNING_THRESHOLD" ]; then
        echo "Warning DBSIZE=$DBSIZE MB | DBSIZE=$DBSIZE"MB";;;;"
        exit $STATE_WARNING
else
        echo "UNKNOWN ERROR."
        exit $STATE_UNKNOWN
fi
}

checkResult
