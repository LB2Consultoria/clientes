#!/usr/bin/python
# -*- coding: utf-8 -*-
# -------------------------------------------------------------
# LB2 Schedule Downtime
#           Simple script to put several services into downtime
#           on Nagios.
#
#       Autor: Bernardo S E Vale
#       Data Inicio:  22/09/2015
#       Data Release: 24/09/2015
#       email: bernardo.vale@lb2.com.br
#       Versão: v1.0
#       LB2 Consultoria - Leading Business 2 the Next Level!
#---------------------------------------------------------------
import json
import os
import sys
from time import time
import urllib
import urllib2


class Utils:
    @staticmethod
    def read_json(json_str):
        try:
            return json.loads(json_str)
        except ValueError:
            print "Error while trying to read JSON file"
            return None

    @staticmethod
    def build_json(json_path):
        """
        Build a JSON file
        :param json_path: str: JSON file
        :return dict: Dictionary based on JSON file
        """
        if Utils.file_exists(json_path):
            with open(json_path) as opf:
                try:
                    return json.load(opf)
                except ValueError:
                    print "Erro ao ler o arquivo JSON de configuracao."
                    return None
        else:
            print "Impossivel encontrar o arquivo de configuracao. %s" % json_path
            return None

    @staticmethod
    def fullpath(file_name):
        """
        Full path of a given file
        :param file_name: str
        :return: str
        """
        return "%s/%s" % (os.path.dirname(sys.argv[0]), file_name)

    @staticmethod
    def file_exists(path):
        """
        Garante que o arquivo existe no SO
        :param path: Path do arquivo
        :return: Afirmação
        """
        # Agora tambem sei brincar de lambda
        x = lambda y: True if os.path.isfile(y) and os.access(y, os.R_OK) else False
        return x(path)


class Config:
    def __init__(self):
        self.server = ''
        self.user = ''
        self.password = ''
        self.nrdptoken = ''
        self.schedule_list = []


class Schedule:
    def __init__(self):
        self.host = ''
        self.service_list = []
        self.duration = 0
        self.comment = ""


def find_schedules(schedule_dict):
    schedule_list = []
    for schedule in schedule_dict:
        s = Schedule()
        s.host = schedule['host']
        s.service_list = schedule['service_list']
        s.duration = schedule['duration']
        s.comment = schedule['comment']
        schedule_list.append(s)
    return schedule_list


def build_configurator(config_file):
    """
    Build a Config class based on JSON File
    :param config_file: str
    :return: Config
    """
    config_json = Utils.build_json(config_file)
    if config_json is not None:
        config = Config()
        config.nrdptoken = config_json['nagios']['nrdptoken']
        config.user = config_json['nagios']['user']
        config.password = config_json['nagios']['password']
        config.server = config_json['nagios']['server']
        config.schedule_list = find_schedules(config_json['schedule_list'])
    return config


def get_interval_date(duration):
    """
    return two dates in epoch UNIX format
    :param duration: int: seconds
    :return: tuple
    """
    now = int(time())
    end = now + duration
    return now, end


def service_name_converter(service):
    """
    Convert given if need.
    Nagios doesn't interpret whitespaces and slashes
    :param service: str
    :return: str
    """
    service = urllib.quote_plus(service)
    return service


def send_services_downtime(config, schedule, is_testing):
    """
    Send downtime to all services from a give schedule policy
    :param config: Config
    :param schedule: Schedule
    :param is_testing: bool
    :return: bool
    """
    for service in schedule.service_list:
        now, end = get_interval_date(schedule.duration)
        converted_service = service_name_converter(service)
        converted_host = service_name_converter(schedule.host)
        converted_comment = service_name_converter(schedule.comment)
        url = "http://%s/nrdp/?cmd=submitcmd&token=%s&command=SCHEDULE_SVC_DOWNTIME;%s;%s;%s;%s;1;0;300;%s;%s" % \
              (config.server, config.nrdptoken, converted_host, converted_service, now, end, config.user,
               converted_comment)
        if is_testing:
            print 'Calling:%s' % url
        else:
            try:
                response = urllib2.urlopen(url).read()
            except urllib2.HTTPError:
                print "Couldn't fetch given url: %s" % url
                exit(3)
            if not '<message>OK</message>' in response:
                print "Somethig bad happened while scheduling downtime. Check the nagios response:\n %s" % response
                return False
    return True


def send_remove_downtime(config, down_list, is_testing):
    """
    Remove all downtime for given services
    :param config: Config
    :param down_list: Schedule
    :param is_testing: bool
    :return: bool
    """
    for downtime_id in down_list:
        url = "http://%s/nrdp/?cmd=submitcmd&token=%s&command=DEL_SVC_DOWNTIME;%s" % (config.server,
                                                                                      config.nrdptoken, downtime_id)
        if is_testing:
            print 'Calling:%s' % url
        else:
            try:
                response = urllib2.urlopen(url).read()
            except urllib2.HTTPError:
                print "Couldn't fetch given url: %s" % url
                exit(3)
            if not '<message>OK</message>' in response:
                print "Somethig bad happened while removing downtime. Check the nagios response:\n %s" % response
                return False
    return True


def services_downtime(config, downtime_id_list):
    """
    Check
    :param config: Config
    :param downtime_id_list: []
    :return: [{}]
    """
    services_in_downtime = []
    for downtime_id in downtime_id_list:
        open_conn(config.user, config.password, config.server)
        url = "http://%s/nagios/cgi-bin/statusjson.cgi?query=downtime&downtimeid=%s" % (config.server, downtime_id)
        try:
            response = urllib2.urlopen(url).read()
        except urllib2.HTTPError:
            print "Couldn't fetch given url: %s" % url
            exit(3)
        json_response = Utils.read_json(response)
        service = json_response['data']['downtime']['service_description']
        services_in_downtime.append(({service: downtime_id}))
    return services_in_downtime


def remove_downtime_not_on_policy(downtime_list, service_list):
    """
    I want to clean only those downtimes that are inside my
    policy. This method make sure only downtime id from services
    that are inside the policy will be cleaned
    :param downtime_list: []
    :param service_list:  [{}]
    :return: []: List of downtime id
    """
    cleaned_downtime_list = []
    for service_downtime in downtime_list:
        for service_name in service_list:
            if service_name in service_downtime:
                cleaned_downtime_list.append(service_downtime[service_name])
    return cleaned_downtime_list


def validate_downtime(config, schedule, is_testing):
    """
    This is a method to confirm that a given a service
    is in downtime and to get all downtime ID
    :param config: Config
    :param schedule: Downtime
    :param is_testing: bool
    :return: []
    """
    host_downtime_list = downtime_list(config, schedule, is_testing)
    if host_downtime_list:
        services_in_downtime = services_downtime(config, host_downtime_list)
        host_downtime_list = remove_downtime_not_on_policy(services_in_downtime, schedule.service_list)
        return host_downtime_list
    else:
        return host_downtime_list


def downtime_list(config, schedule, is_testing):
    """
    This is a method to list all downtime ID's
    of a host
    :param config: Config
    :param schedule: Downtime
    :param is_testing: bool
    :return: []
    """
    #todo modulo testing
    open_conn(config.user, config.password, config.server)
    url = "http://%s/nagios/cgi-bin/statusjson.cgi?query=downtimelist&hostname=%s" % (config.server, schedule.host)
    try:
        response = urllib2.urlopen(url).read()
    except urllib2.HTTPError:
        print "Couldn't fetch given url: %s" % url
        exit(3)
    json_response = Utils.read_json(response)
    downtime_list = json_response['data']['downtimelist']
    return downtime_list


def downtime_handler(config, module, is_testing):
    """
    Schedule downtime for all schedule policies or clean downtime
    :param config: Config
    :param module: str
    :param is_testing: Boll
    :return: Bool
    """
    #First, validate if all hosts exists and if the comunication with Nagios is possible
    for schedule in config.schedule_list:
        if not is_host(schedule.host, config):
            print "The host %s isn't a known host on nagios!" % schedule.host
            return False
        # Second, validate if all services from given policies exists on given host.
        if not service_exists(config, schedule.host, schedule.service_list):
            print "Some services from host %s doesn't exists on nagios!" % schedule.host
            return False
        #Send downtime
        if module == 'downtime':
            if not send_services_downtime(config, schedule, is_testing):
                print "Couldn't schedule downtime from given host %s " % schedule.host
                return False
        elif module == 'clean':
            down_list = validate_downtime(config, schedule, is_testing)
            if down_list:
                if not send_remove_downtime(config, down_list, is_testing):
                    print "Couldn't schedule downtime from given host %s " % schedule.host
                    return False
            else:
                print "Given services aren't in downtime!"
                return False
    return True


def open_conn(user, password, server):
    """
    Open an authenticated connection from the given
    URL
    :param user: str
    :param password: str
    :return: urllib2.OpenerDirector
    """
    password_mgr = urllib2.HTTPPasswordMgrWithDefaultRealm()
    base_url = "http://%s/nagios/" % server
    password_mgr.add_password(None, base_url, user, password)
    handler = urllib2.HTTPBasicAuthHandler(password_mgr)
    opener = urllib2.build_opener(handler)
    urllib2.install_opener(opener)


def service_exists(config, host, service_list):
    """
    Test if all services exists on host
    :param config: Config
    :param host: str
    :param service_list: []
    :return: Bool
    """
    url = "http://%s/nagios/cgi-bin/objectjson.cgi?query=servicelist&hostname=%s" % (config.server, host)
    open_conn(config.user, config.password, config.server)
    try:
        response = urllib2.urlopen(url).read()
    except urllib2.HTTPError:
        print "Couldn't fetch given url: %s" % url
        exit(3)
    json_response = Utils.read_json(response)
    all_services = json_response['data']['servicelist'][host]
    return set(service_list) <= set(all_services)


def is_host(host, config):
    """
    Test if given name it's a valid host on Nagios
    :param host: str
    :param config: Config
    :return:
    """
    url = "http://%s/nagios/cgi-bin/objectjson.cgi?query=hostlist" % config.server
    open_conn(config.user, config.password, config.server)
    try:
        response = urllib2.urlopen(url).read()
    except urllib2.HTTPError:
        print "Couldn't fetch given url: %s" % url
        exit(3)
    json_response = Utils.read_json(response)
    host_list = json_response['data']['hostlist']
    return True if host in host_list else False


def parse_args(argv):
    """
    Analisa os argumentos. Foi feito de maneira simples
    para nao ficar dependente do argparse
    :param argv: Argumentos do script
    :return: str: politica
    """
    schedule_policy = None
    module = None
    testing = False
    if len(argv) > 1:
        schedule_policy = argv[0]
        if str(argv[1]).lower() == '--downtime' or str(argv[1]).lower() == '-d':
            module = 'downtime'
        elif str(argv[1]).lower() == '--clean' or str(argv[1]).lower() == '-c':
            module = 'clean'
        if len(argv) >= 3:
            if str(argv[2]).lower() == '--test' or str(argv[2]).lower() == '-t':
                testing = True
    return schedule_policy, module, testing


def main(argv):
    schedule_policy, module, is_testing = parse_args(argv)
    if schedule_policy is not None and module is not None:
        config = build_configurator(schedule_policy)
        if downtime_handler(config, module, is_testing):
            print "All policies were executed sucessfully!!"
            exit(0)
        else:
            print "Some policies weren't executed!"
            exit(2)
    else:
        print "Set downtime for given policies:"
        print "Usage: ./schedule_downtime.py mypolicy.json --downtime"
        print "Remove downtime for given policies:"
        print "Usage: ./schedule_downtime.py mypolicy.json --clean"
        print "Test a module:"
        print "Usage: ./schedule_downtime.py mypolicy.json --downtime --test"
        print "Usage: ./schedule_downtime.py mypolicy.json --clean --test"
        exit(3)


if __name__ == '__main__':
    main(sys.argv[1:])