import htmlentitydefs
from time import gmtime, mktime, time
import unittest
from schedule_downtime import *
import mock
from mock import PropertyMock
from mock import MagicMock

class TestDowntime(unittest.TestCase):
    """
    Testes relacionados aos schedule downtime
    """
    def setUp(self):
        pass


    def test_is_host(self):
        c = Config()
        c.server = '10.200.0.113'
        c.user = 'bernardo.vale'
        c.nrdptoken = 'reactor'
        c.password = 'eduarda1992'
        my_host = 'Flessak-PRD'
        self.assertTrue(is_host(my_host, c))

    def test_not_host(self):
        c = Config()
        c.server = '10.200.0.113'
        c.user = 'bernardo.vale'
        c.nrdptoken = 'reactor'
        c.password = 'eduarda1992'
        my_host = 'CAPA DE PIQUE'
        self.assertFalse(is_host(my_host, c))

    def test_is_host_whitespaces(self):
        c = Config()
        c.server = '10.200.0.113'
        c.user = 'bernardo.vale'
        c.nrdptoken = 'reactor'
        c.password = 'eduarda1992'
        my_host = 'LB2 BPI'
        self.assertTrue(is_host(my_host, c))

    def test_all_services(self):
        c = Config()
        c.server = '10.200.0.113'
        c.user = 'bernardo.vale'
        c.nrdptoken = 'reactor'
        c.password = 'eduarda1992'
        my_host = 'Flessak-PRD'
        service_list = ['check_load', 'check_uptime', 'check_rman']
        self.assertTrue(service_exists(c, my_host, service_list))

    def test_all_services_whitespaces(self):
        c = Config()
        c.server = '10.200.0.113'
        c.user = 'bernardo.vale'
        c.nrdptoken = 'reactor'
        c.password = 'eduarda1992'
        my_host = 'LB2-TOTVS'
        service_list = ['TOTVS NF-E', 'TOTVS DBAccess Memory']
        self.assertTrue(service_exists(c, my_host, service_list))

    def test_all_services_whitespaces_failure(self):
        c = Config()
        c.server = '10.200.0.113'
        c.user = 'bernardo.vale'
        c.nrdptoken = 'reactor'
        c.password = 'eduarda1992'
        my_host = 'LB2-TOTVS'
        service_list = ['TOTVS NF-E', ' capa de pica']
        self.assertFalse(service_exists(c, my_host, service_list))

    def test_host_with_single_service(self):
        c = Config()
        c.server = '10.200.0.113'
        c.user = 'bernardo.vale'
        c.nrdptoken = 'reactor'
        c.password = 'eduarda1992'
        my_host = 'lotus.lb2.com.br'
        service_list = ['LDAP Server']
        self.assertTrue(service_exists(c, my_host, service_list))

    def test_host_with_single_service_sercomtel(self):
        c = Config()
        c.server = '192.168.2.146'
        c.user = 'bernardo.vale'
        c.nrdptoken = 'reactor'
        c.password = 'sercomtel1992'
        my_host = 'CLARIION.15.30'
        service_list = ['Ping']
        self.assertTrue(service_exists(c, my_host, service_list))

    def test_send_downtime(self):
        c = Config()
        c.server = '192.168.2.146'
        c.user = 'bernardo.vale'
        c.nrdptoken = 'reactor'
        c.password = 'sercomtel1992'
        my_host = 'svnotes'
        service_list = ['Ping', 'SSH']
        schedule = Schedule()
        schedule.host = my_host
        schedule.comment = 'my test'
        schedule.duration = 120
        schedule.service_list = service_list
        self.assertTrue(send_services_downtime(c, schedule))

    def test_send_downtime_lb2(self):
        c = Config()
        c.server = '10.200.0.113'
        c.user = 'bernardo.vale'
        c.nrdptoken = 'reactor'
        c.password = 'eduarda1992'
        my_host = 'LB2 BPI'
        service_list = ['BPI Process:PBLopes']
        schedule = Schedule()
        schedule.host = my_host
        schedule.comment = 'my test'
        schedule.duration = 120
        schedule.service_list = service_list
        self.assertTrue(send_services_downtime(c, schedule))

    def test_epoch(self):
        duration = 120
        now = int(time())
        print now
        end = now + duration
        print end

    def test_service_converter(self):
        service = 'capa de pica'
        self.assertEqual(service_name_converter(service), 'capa+de+pica')
        service = '/ capa de pica /'
        self.assertEqual(service_name_converter(service), '%2F+capa+de+pica+%2F')
        service = 'Porta 1158: dbControl OMS'
        self.assertEqual(service_name_converter(service), 'Porta+1158%3A+dbControl+OMS')

    def test_clean_downtime(self):
        downtime_list = [{'check_load' : 244}, {'check_disk' : 233}, {'check_capa': 233}]
        service_list = ['check_load', 'check_disk']
        got = remove_downtime_not_on_policy(downtime_list, service_list)
        expected = [244, 233]
        self.assertEqual(got, expected)

    def test_clean_downtime_doesnt_exists(self):
        downtime_list = []
        service_list = ['check_load', 'check_disk']
        got = remove_downtime_not_on_policy(downtime_list, service_list)
        expected = []
        self.assertEqual(got, expected)

    @mock.patch('schedule_downtime.downtime_list')
    @mock.patch('schedule_downtime.services_downtime')
    def test_validate_downtime(self, downtime_mocked, services_mocked):
        c = Config()
        c.server = '10.200.0.113'
        c.user = 'bernardo.vale'
        c.nrdptoken = 'reactor'
        c.password = 'eduarda1992'
        fake_downtime_list = [233, 244, 255]
        fake_services_in_downtime = []
        downtime_mocked.return_value = fake_downtime_list
        services_mocked.return_value = fake_services_in_downtime
        got = validate_downtime(Config(), Schedule(), False)
        expected = []
        self.assertEqual(got, expected)

    @mock.patch('schedule_downtime.services_downtime')
    @mock.patch('schedule_downtime.downtime_list')
    def test_validate_downtime_lot_of_services(self, downtime_mocked, services_mocked):
        c = Config()
        c.server = '10.200.0.113'
        c.user = 'bernardo.vale'
        c.nrdptoken = 'reactor'
        c.password = 'eduarda1992'
        fake_downtime_list = [233, 255]
        fake_services_in_downtime = [{'check_teste' : 233}, {"capa" : 256}, {'aloga' : 255}]
        downtime_mocked.return_value = fake_downtime_list
        services_mocked.return_value = fake_services_in_downtime
        s = Schedule()
        s.service_list = ["check_teste", "capa"]
        got = validate_downtime(Config(), s, False)
        expected = [233, 256]
        self.assertEqual(got, expected)