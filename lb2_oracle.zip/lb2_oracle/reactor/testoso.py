

my_dict_list = [{'check_load' : 244}, {'check_disk' : 233}, {'check_capa': 233}]
list_of_services = ['check_load', 'check_disk']

downtime_list = []
for service_downtime in my_dict_list:
    for service_name in list_of_services:
        if service_name in service_downtime:
            downtime_list.append(service_downtime[service_name])

print downtime_list