# Conecta no producao e traz informacoes
export PROD_LAST_LOG=`/u01/app/oracle/product/12.2.0/db_1/bin/sqlplus -sL sys/alsk1029QWE#@$danieli as sysdba << EOF
        set echo off heading off feedback off
        alter session set nls_date_format='YYYY-MM-DD HH24:MI';
        select SEQUENCE#||' '||FIRST_TIME from v\\$archived_log where FIRST_TIME=(select max(first_time) from v\\$archived_log);
        exit
EOF`

echo $PROD_LAST_LOG
