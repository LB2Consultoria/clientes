import unittest
from utils.database_utils import Db


class TestDatabase(unittest.TestCase):
    """
    Testes relacionados aos utilitarios de Database
    """
    def setUp(self):
        pass


    def test_parse_arguments(self):
        self.result_01 = "Administrative			 3116 SPACING \n" \
"Application		      7375426 SPACING\n" \
"Cluster  2819549 SPACING \n" \
"Commit				11517 SPACING \n" \
"Concurrency		      2340832 SPACING \n" \
"Configuration			  593 SPACING \n" \
"Network 		       152641 SPACING \n" \
"Other			      1548103 SPACING \n" \
"Scheduler			   17 SPACING \n" \
"System_I/O		       241911 SPACING \n" \
"User_I/O		     14090487 SPACING"
        self.result_02 ="Administrative			 4620 SPACING \n" \
"Application			45898 SPACING \n" \
"Commit			     31486926 SPACING \n" \
"Concurrency		       742917 SPACING \n" \
"Configuration			16250 SPACING \n" \
"Network 		       143174 SPACING \n" \
"Other			      4198170 SPACING \n" \
"Scheduler		      3350413 SPACING \n" \
"System_I/O		     78208013 SPACING \n" \
"User_I/O		      6102614 SPACING"
        self.result_03 = "Administrative			 4620 \n" \
"Application			45898 \n" \
"Commit			     31489478 \n" \
"Concurrency		       742917 \n" \
"Configuration			16250 \n" \
"Network 		       143178 \n" \
"Other			      4198711 \n" \
"Scheduler		      3350413 \n" \
"System_I/O		     78220742 \n" \
"User_I/O		      6103058 "
        result_list = [self.result_01, self.result_02, self.result_03]
        for result in result_list:
            r = Db.parse_result(result, "SPACING")
            self.assertTrue(r, [[]])
            for line in r:
                self.assertTrue(line[0], str)
                self.assertTrue(int(line[1]), int)
                self.assertTrue(len(line), 2)
                cond = any(char.isdigit() for char in line[0])
                self.assertFalse(cond)