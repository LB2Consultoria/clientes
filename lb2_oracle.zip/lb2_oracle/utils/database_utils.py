from utils.monitoramento_utils import Utils


class Db:

    @staticmethod
    def single_string_query(user, password, sid, query):
        global r
        if user.lower() == 'sys':
            result = Utils.run_sqlplus(password, user, sid, query, True, True)
        else:
            result = Utils.run_sqlplus(password, user, sid, query, True, False)
        if 'ORA-' in result:
            print 'Erro desconhecido ao executar a query:' + result
            exit(3)
        try:
            r = result.strip(' ').replace(',', '.')
        except:
            print 'Impossivel tratar o resultado da query: %s' % result
            exit(3)
        return str(r)

    @staticmethod
    def parse_result(result, delimiter=None):
        """
        Parse query result
        :param result: str: Result
        :param delimiter: str: line delimiter
        :return: [[]]
        """
        #Limpar as bordas
        result = result.strip()
        # Remover o delimitador de colunas
        result = result.replace("|", " ")
        result = result.replace("\t", " ")
        if delimiter:
            result = result.replace(delimiter, " ")
        result = result.split("\n")
        result = [s.split() for s in result]
        return result

    @staticmethod
    def multiple_query(user, password, sid, query):
        """

        :param user: string: user
        :param password: string: password
        :param sid: string: sid
        :param query: String: Consulta
        :return: [[]]
        """
        if user.lower() == 'sys':
            result = Utils.run_sqlplus(password, user, sid, query, False, True)
        else:
            result = Utils.run_sqlplus(password, user, sid, query, False, False)
        if 'ORA-' in result:
            print "UNKNOWN - Impossivel tratar a consulta"
            exit(3)
        result = Db.parse_result(result)
        return result

    @staticmethod
    def single_int_query(user, password, sid, query):
        """
        Executa qualquer query que retorne 1 valor
        inteiro
        :param user: Usuario do oracle
        :param password: Senha do oracle
        :param sid: tnsnames de conexao
        :param query: Diskgroup dos archives
        :return:
        """
        global r
        if user.lower() == 'sys':
            result = Utils.run_sqlplus(password, user, sid, query, True, True)
        else:
            result = Utils.run_sqlplus(password, user, sid, query, True, False)
        if 'ORA-' in result:
            print 'Erro desconhecido ao executar a query:' + result
            exit(3)
        try:
            r_aux = result.strip(' ').replace(',', '.')
            if '.' in r_aux:
                r = int(round(float(r_aux)))
            else:
                r = int(r_aux)
        except:
            print 'Impossivel tratar o resultado da query: %s' % result
            exit(3)
        return r