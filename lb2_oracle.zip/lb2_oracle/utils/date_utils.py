import datetime

__author__ = 'bernardovale'

class DateUtils:

    @staticmethod
    def get_date_hour():
        return datetime.datetime.now().strftime("%Y%m%d%H%M")
    @staticmethod
    def get_today():
        return datetime.datetime.now().strftime("%Y%m%d")

    @staticmethod
    def hours_delta(date):
        """
        Calc delta hours from given date
        :param date:
        :return:
        """
        current_time = datetime.datetime.now()
        given_date = datetime.datetime.strptime(date, "%Y%m%d%H%M")
        return current_time - given_date